package searchengine.services;

import searchengine.dto.statistics.StatisticsResponse;

public interface StatisticsService {
    // Method to retrieve statistics
    StatisticsResponse getStatistics();
}
