package searchengine.dto.statistics;

import lombok.Value;

@Value
public class Response {
    boolean result;  // Result of the response operation
}
