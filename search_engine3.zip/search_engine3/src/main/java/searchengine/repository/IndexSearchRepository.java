package searchengine.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import searchengine.model.SearchIndex;
import searchengine.model.Lemma;
import searchengine.model.Page;

import java.util.List;

@Repository
public interface IndexSearchRepository extends JpaRepository<SearchIndex, Long> {
    // Custom query to retrieve search indices by lemmas and pages
    @Query(value = "SELECT i.* FROM index_search i WHERE i.lemma_id IN :lemmas AND i.page_id IN :pages", nativeQuery = true)
    List<SearchIndex> findByPagesAndLemmas(@Param("lemmas") List<Lemma> lemmaListId,
                                           @Param("pages") List<Page> pageListId);

    // Retrieve search indices by lemma ID
    List<SearchIndex> findByLemmaId(long lemmaId);

    // Retrieve search indices by page ID
    List<SearchIndex> findByPageId(long pageId);

    // Retrieve a search index by lemma ID and page ID
    SearchIndex findByLemmaIdAndPageId(long lemmaId, long pageId);
}
