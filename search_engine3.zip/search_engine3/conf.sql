CREATE DATABASE IF NOT EXISTS search_engine;
CREATE USER 'root'@'localhost' IDENTIFIED BY 'Rjptk594535';
GRANT ALL PRIVILEGES ON search_engine.* TO 'root'@'localhost';
FLUSH PRIVILEGES;

